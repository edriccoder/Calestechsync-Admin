<?php
require 'conn.php';

if(isset($_POST['save'])) {
    $exname = $_POST['exname'];
    $exdesc = $_POST['exdesc'];
    $exdifficulty = $_POST['exdifficulty'];
    $focusbody = $_POST['focusbody'];

    // Handle file upload
    $target_dir = "eximg/";
    $target_file = $target_dir . basename($_FILES["eximg"]["name"]);
    $uploadOk = 1;
    $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

    // Check if image file is an actual image or fake image
    if(isset($_POST["save"])) {
        $check = getimagesize($_FILES["eximg"]["tmp_name"]);
        if($check !== false) {
            $uploadOk = 1;
        } else {
            echo "<script>alert('File is not an image.');window.location='exercise_func.php'</script>";
            $uploadOk = 0;
        }
    }

    // Check if file already exists
    if (file_exists($target_file)) {
        echo "<script>alert('Sorry, file already exists.');window.location='exercise_func.php'</script>";
        $uploadOk = 0;
    }

    // Check file size (adjusting to 10MB as an example)
    if ($_FILES["eximg"]["size"] > 10000000) { 
        echo "<script>alert('Sorry, your file is too large.');window.location='exercise_func.php'</script>";
        $uploadOk = 0;
    }

    // Allow certain file formats
    if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
    && $imageFileType != "gif" ) {
        echo "<script>alert('Sorry, only JPG, JPEG, PNG & GIF files are allowed.');window.location='exercise_func.php'</script>";
        $uploadOk = 0;
    }

    // Check if $uploadOk is set to 0 by an error
    if ($uploadOk == 0) {
        echo "<script>alert('Sorry, your file was not uploaded.');window.location='exercise_func.php'</script>";
    } else {
        // Attempt to move the uploaded file to the specified directory
        if (move_uploaded_file($_FILES["eximg"]["tmp_name"], $target_file)) {
            // File uploaded successfully, now insert into database
            $sql = "INSERT INTO exercise_records (exname, exdesc, eximg, exdifficulty, focusbody) VALUES (?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("sssss", $exname, $exdesc, $target_file, $exdifficulty, $focusbody);
            if ($stmt->execute()) {
                echo "<script>alert('Exercise record added successfully.');window.location='ExerciseData.php'</script>";
            } else {
                echo "Error: " . $sql . "<br>" . $conn->error;
            }
        } else {
            echo "<script>alert('Sorry, there was an error uploading your file.');window.location='exercise_func.php'</script>";
        }
    }
}
?>