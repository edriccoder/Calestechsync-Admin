<?php
include 'conn.php';

if(isset($_POST['update'])) {
    $excid = $_POST['excid'];
    $exname = $_POST['exname'];
    $exdesc = $_POST['exdesc'];
    $exdifficulty = $_POST['exdifficulty'];
    $focusbody = $_POST['focusbody'];

    // Use '?' as placeholder for each value to be bound
    $query = "UPDATE exercise_records SET exname=?, exdesc=?, exdifficulty=?, focusbody=? WHERE excid=?";
    
    // Prepare the statement
    $stmt = mysqli_prepare($conn, $query);

    // Check for errors in preparing the statement
    if (!$stmt) {
        echo "Error: " . mysqli_error($conn);
        exit;
    }

    // Bind parameters to the statement
    mysqli_stmt_bind_param($stmt, "ssssi", $exname, $exdesc, $exdifficulty, $focusbody, $excid);
    
    // Execute the statement
    $result = mysqli_stmt_execute($stmt);

    // Check for errors in executing the statement
    if (!$result) {
        echo "Error: " . mysqli_error($conn);
        exit;
    }
    
    if($result) {
        echo "<script>alert('Exercise updated successfully!')</script>";
        echo "<script>window.location.href='ExerciseData.php';</script>";
    } else {
        echo "<script>alert('Failed to update exercise. Please try again.')</script>";
    }
}
?>
